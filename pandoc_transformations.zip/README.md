# DHExercise
Exercise in class on Thursday March 2nd, 2023
